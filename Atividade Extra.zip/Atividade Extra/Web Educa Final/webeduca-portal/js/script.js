const RESPOSTA_CORRETA = 3;

const resposta = document.getElementById("resposta");
const botao = document.getElementById("verificar");
const resultado = document.getElementById("resultado");
const botaoTema = document.getElementById("tema");

function verificar() {
    // Limpa a classe para a animação poder repetir
    resultado.className = "";

    if (resposta.value === "") {
        resultado.textContent = "Digite um número antes de verificar.";
        resposta.focus();
        return;
    }

    const numero = Number(resposta.value);

    if (!Number.isInteger(numero) || numero < 0) {
        resultado.textContent = "Digite um número inteiro maior ou igual a zero.";
        resposta.focus();
        return;
    }

    // Força o navegador a reiniciar a animação
    void resultado.offsetWidth;

    if (numero === RESPOSTA_CORRETA) {
        resultado.textContent = "Parabéns! Resposta correta!";
        resultado.classList.add("certo");
    } else {
        resultado.textContent = "Resposta incorreta. Dica: conte os itens da lista e tente novamente.";
        resultado.classList.add("errado");
    }
}

botao.addEventListener("click", verificar);

resposta.addEventListener("keydown", function (evento) {
    if (evento.key === "Enter") {
        verificar();
    }
});

// Modo escuro com alternância de tema
function aplicarTema(tema) {
    document.documentElement.setAttribute("data-theme", tema);
    const escuro = tema === "dark";
    botaoTema.setAttribute("aria-pressed", String(escuro));
    botaoTema.textContent = escuro ? "Modo claro" : "Modo escuro";
}

function temaInicial() {
    try {
        const salvo = localStorage.getItem("tema");
        if (salvo === "dark" || salvo === "light") {
            return salvo;
        }
    } catch (erro) {
        // localStorage indisponível: segue com a preferência do sistema
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

botaoTema.addEventListener("click", function () {
    const novo = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    aplicarTema(novo);
    try {
        localStorage.setItem("tema", novo);
    } catch (erro) {
        // sem persistência, o tema vale só nesta visita
    }
});

aplicarTema(temaInicial());
