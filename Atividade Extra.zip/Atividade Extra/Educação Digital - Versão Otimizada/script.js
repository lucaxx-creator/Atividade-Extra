const formulario = document.querySelector("#form-pesquisa");
const campoCurso = document.querySelector("#curso");
const resultado = document.querySelector("#resultado");
const cursos = document.querySelectorAll(".curso");

function normalizar(texto) {
 return texto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

formulario.addEventListener("submit", function (evento) {
 evento.preventDefault();
 const curso = campoCurso.value.trim();
 if (curso === "") {
 cursos.forEach(function (item) { item.hidden = false; });
 resultado.textContent = "Digite o nome de um curso.";
 campoCurso.focus();
 return;
 }
 const termo = normalizar(curso);
 let encontrados = 0;
 cursos.forEach(function (item) {
 const titulo = normalizar(item.querySelector("h3").textContent);
 const achou = titulo.includes(termo);
 item.hidden = !achou;
 if (achou) { encontrados++; }
 });
 resultado.textContent = encontrados > 0
 ? `Pesquisa realizada: ${curso} (${encontrados} curso(s) encontrado(s))`
 : `Nenhum curso encontrado para: ${curso}`;
});
