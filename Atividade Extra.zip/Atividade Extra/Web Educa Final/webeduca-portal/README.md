# WebEduca — Portal de Aprendizagem

Aplicação web estática (HTML5, CSS3 e JavaScript) sobre algoritmos, com um teste interativo.

## Estrutura

```
index.html
css/style.css
js/script.js
img/favicon.svg
```

## Como executar
Abra o `index.html` no navegador. Não precisa de servidor nem de instalação.

## Publicação (GitHub Pages)
1. Crie um repositório público no GitHub e envie estes arquivos.
2. Em Settings > Pages, escolha a branch `main` e a pasta `/ (root)`.
3. Aguarde alguns minutos e acesse o endereço gerado.

## Melhorias implementadas (atividade 7.2)

- **Seção de apresentação do projeto:** seção "Sobre o projeto" no início da página.
- **Menu de navegação responsivo:** links no cabeçalho que se reorganizam em telas pequenas, com link "Ir para o conteúdo" para quem usa teclado.
- **Mensagens de validação e retorno:** o quiz avisa quando o campo está vazio, quando o número não é inteiro ou é negativo, e dá uma dica quando a resposta está errada. O resultado é anunciado por leitores de tela (`aria-live`).
- **Modo escuro com alternância de tema:** botão no cabeçalho; a escolha fica salva no navegador (`localStorage`) e, na primeira visita, segue a preferência do sistema.
- **Documentação:** este README descreve estrutura, execução, publicação e as melhorias.
