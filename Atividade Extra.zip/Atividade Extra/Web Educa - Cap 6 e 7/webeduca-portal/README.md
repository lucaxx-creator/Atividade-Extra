# WebEduca — Portal de Aprendizagem

Aplicação web estática (HTML5, CSS3 e JavaScript) sobre algoritmos, com um teste interativo.

## Estrutura

```
index.html
css/style.css
js/script.js
img/favicon.svg
```

## Como executar
Abra o `index.html` no navegador. Não precisa de servidor nem de instalação.

## Publicação (GitHub Pages)
1. Crie um repositório público no GitHub e envie estes arquivos.
2. Em Settings > Pages, escolha a branch `main` e a pasta `/ (root)`.
3. Aguarde alguns minutos e acesse o endereço gerado.
